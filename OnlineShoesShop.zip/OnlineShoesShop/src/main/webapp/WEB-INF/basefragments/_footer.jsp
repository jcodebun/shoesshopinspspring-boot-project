<%@page import="java.util.Date"%>
<%@page import="java.text.SimpleDateFormat"%>
<footer class="footer mt-auto py-3" style="background-color: #00061df7">
  <div class="container">
    <span class="text-muted">Copyright &copy <%= new SimpleDateFormat("yyyy").format(new Date()) %>Online Shoes Shop . All Rights Reserved.</span>
  </div>
</footer>
